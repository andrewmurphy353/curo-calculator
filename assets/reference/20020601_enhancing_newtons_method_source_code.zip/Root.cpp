/*
  Program that compares Newton's method with the
  Enhanced Newton and Quad Newton methods.

  Author: Namir Clement Shammas.
  Date: November 1, 2001
  
*/

#pragma hdrstop
#include <math.h>
#include <iostream.h>
#include <fstream.h>

void pressAnyKey(char* sMsg)
{
  char c[2];
  cout << sMsg;
  cin.getline(c, 1);
}

double f1(double x)
{
  return exp(x) - 3 * x * x;
}

double f2(double x)
{
  return  cos(x) - x;
}

double f3(double x)
{
  return (x + 15) * (x + 10) * (x + 20) * (x - 4.5);
}

double f4(double x)
{
  return pow(cosh(x),2) + pow(sinh(x),2) + 2 * x - 11 ;
}

double f5(double x)
{
  double fSum = 100;
  double fPow = 1;

  for (int i = 1; i < 5; i++) {
    fPow *= x;
    fSum -= fPow / i;
  }
  return fSum;

}

class CRoot
{
  public:
    CRoot(int nMaxIter = 50,
          double fToler = 1.0e-7);
    int getIters()
      { return m_nIter; }
    double Newton(double fGuess,
                  double (*f)(double x));
    double ExRoot(double fGuess,
                  double (*f)(double x));
    double QuadRoot(double fGuess,
                  double (*f)(double x));
  protected:
    int m_nMaxIter;
    int m_nIter;
    double m_fToler;
};

CRoot::CRoot(int nMaxIter, double fToler)
{
  m_nMaxIter = nMaxIter;
  m_fToler = fToler;
  m_nIter = 0;
}

double CRoot::Newton(double fGuess, double (*f)(double x))
{
  double h, fDiff;

  m_nIter = 0;
  do {
    h = (fabs(fGuess) > 1.0 ? 0.01 * fGuess : 0.01);
    fDiff = 2 * h * (*f)(fGuess) /((*f)(fGuess + h) - (*f)(fGuess - h));
    fGuess -= fDiff;
  } while (++m_nIter < m_nMaxIter && fabs(fDiff) > m_fToler);

  return fGuess;
}

double CRoot::ExRoot(double fGuess, double (*f)(double x))
{
  double h, fDiff;
  double f0, fp, fm;
  double fDeriv1, fDeriv2;
  double r0, r1;

  m_nIter = 0;
  do {
    h = (fabs(fGuess) > 1.0 ? 0.01 * fGuess : 0.01);
    // calculate function values at x, x+h, and x-h
    f0 = (*f)(fGuess);
    fp = (*f)(fGuess + h);
    fm = (*f)(fGuess - h);
    // calculate first and second derivatives
    fDeriv1 = (fp - fm) / (2 * h);
    fDeriv2 = (fp - 2 * f0 + fm) / (h  * h);
    // calculate 1st guess
    r0 = fGuess - f0 / fDeriv1;
    // calculate refinement of guess
    r1 = fGuess - f0 / (fDeriv1 + fDeriv2 * (r0 - fGuess) / 2);
    // calculate guess update
    fDiff = f0 / (fDeriv1 + fDeriv2 * (r1 - fGuess) / 2);
    fGuess -= fDiff;
  } while (++m_nIter < m_nMaxIter && fabs(fDiff) > m_fToler);

  return fGuess;
}

double CRoot::QuadRoot(double fGuess, double (*f)(double x))
{
  double h, fDiff;
  double f0, fp, fm;
  double fDeriv1, fDeriv2;
  double r, d;

  m_nIter = 0;
  do {
    h = (fabs(fGuess) > 1.0 ? 0.01 * fGuess : 0.01);
    // calculate function values at x, x+h, and x-h
    f0 = (*f)(fGuess);
    fp = (*f)(fGuess + h);
    fm = (*f)(fGuess - h);
    // calculate first and second derivatives
    fDeriv1 = (fp - fm) / (2 * h);
    fDeriv2 = (fp - 2 * f0 + fm) / (h  * h);
    // calculate guess update
    d = fDeriv1 * fDeriv1 - 2 * f0 * fDeriv2;
    // special override which MIGHT help convergence
    if (d < 0.0) d = 0.0;
    if (d >= 0.0 & fabs(fDeriv2) > 1.e-10) {
      fDiff = (fDeriv1 - sqrt(d)) / fDeriv2;
      fGuess -= fDiff;
    }
    else {
      cout << "Error for guess = " << fGuess << " at iteration "
           << ++m_nIter << endl;
      m_nIter = m_nMaxIter;
      return -1.0E+100;
    }
  } while (++m_nIter < m_nMaxIter && fabs(fDiff) > m_fToler);

  return fGuess;
}

void output(fstream& fout, fstream& f, CRoot& objRoot, double fX,
            double (*fofx)(double x))
{
  double fRoot;

  cout <<  "Initial guess = " << fX << endl;
  fout <<  "Initial guess = " << fX << endl;
  fRoot = objRoot.Newton(fX, fofx);
  cout << "Root using Newton = " << fRoot ;
  fout << "Root using Newton = " << fRoot ;
  cout << " in " << objRoot.getIters() << " iterations" << endl;
  fout << " in " << objRoot.getIters() << " iterations" << endl;
  f << fX << "," << fRoot << "," << objRoot.getIters() << endl;
  fRoot = objRoot.ExRoot(fX, fofx);
  cout << "Root using iterative enhanced Newton  = " << fRoot;
  fout << "Root using iterative enhanced Newton  = " << fRoot;
  cout << " in " << objRoot.getIters() << " iterations" << endl;
  fout << " in " << objRoot.getIters() << " iterations" << endl;
  f << fX << "," << fRoot << "," << objRoot.getIters() << endl;
  fRoot = objRoot.QuadRoot(fX, fofx);
  cout << "Root using quardartic enhanced Newton  = " << fRoot;
  fout << "Root using quardartic enhanced Newton  = " << fRoot;
  cout << " in " << objRoot.getIters() << " iterations" << endl;
  fout << " in " << objRoot.getIters() << " iterations" << endl;
  f << fX << "," << fRoot << "," << objRoot.getIters() << endl;
}

int main(int argc, char* argv[])
{
  CRoot objRoot;
  fstream fout("\\root.dat");
  fstream f("\\rootCDD.dat");
  double fX, fRoot;

  cout << "Solving exp(x) - 3 * x * x" << endl;
  fout << "Solving exp(x) - 3 * x * x" << endl;
  for (int i = 0; i <= 6; i++) {
    fX = 3 + 0.5 * i;
    output(fout, f, objRoot, fX, f1);
    if (i == 3)
      pressAnyKey("Press Enter to continue");
  }
  pressAnyKey("Press Enter to continue");

  cout << endl;
  fout << endl;
  f << endl;
  cout << "Solving cos(x) - x" << endl;
  fout << "Solving cos(x) - x" << endl;
  for (int i = 0; i <= 2; i++) {
    fX = i;
    output(fout, f, objRoot, fX, f2);
  }
  pressAnyKey("Press Enter to continue");

  cout << endl;
  fout << endl;
  f << endl;
  cout << "Solving polynomial" << endl;
  fout << "Solving polynomial" << endl;
  for (int i = 3; i <= 6; i++) {
    fX = i;
    output(fout, f, objRoot, fX, f3);
  }

  pressAnyKey("Press Enter to continue");

  cout << endl;
  fout << endl;
  f << endl;
  cout << "Solving cosh(x)^2 + sinh(x)^2 + 2 * x - 11" << endl;
  fout << "Solving cosh(x)^2 + sinh(x)^2 + 2 * x - 11" << endl;
  for (int i = 1; i <= 4; i++) {
    fX = 0.5 * i;
    output(fout, f, objRoot, fX, f4);
 }

  pressAnyKey("Press Enter to continue");

  cout << endl;
  fout << endl;
  f << endl;
  cout << "Solving summation function" << endl;
  fout << "Solving summation function" << endl;
  for (int i = 0; i <= 8; i++) {
    fX = 1 + 0.5 * i;
    output(fout, f, objRoot, fX, f5);
   if (i == 4)
      pressAnyKey("Press Enter to continue");
 }


  pressAnyKey("Press Enter to end the program");

  fout.close();
  f.close();
  return 0;
}
//---------------------------------------------------------------------------
